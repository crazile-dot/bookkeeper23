# Slack to email digest bot

This script is responsible for generating daily per channel digests and emailing them to certail mailing lists.

